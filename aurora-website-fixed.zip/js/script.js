// ========================================
// Aurora E-commerce - Main JavaScript
// Store: Aurora | Tagline: The art of everyday elegance
// ========================================

// Product catalog (stored in a JavaScript array)
const PRODUCTS = [
  {
    id: 1,
    name: "Leather Chelsea Boots",
    category: "shoes",
    price: 129.00,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1608286791690-0b7c07779316?w=600&q=80",
    desc: "Handcrafted leather boots with a sleek silhouette and cushioned insole."
  },
  {
    id: 2,
    name: "Minimalist Wristwatch",
    category: "watches",
    price: 189.00,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80",
    desc: "Elegant analog watch with a clean dial and genuine leather strap."
  },
  {
    id: 3,
    name: "Oversized Cotton Hoodie",
    category: "hoodies",
    price: 79.00,
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1556821840-3a63f5295944?w=600&q=80",
    desc: "Soft, oversized hoodie in premium cotton blend for everyday comfort."
  },
  {
    id: 4,
    name: "Wool Trench Coat",
    category: "jackets",
    price: 249.00,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80",
    desc: "Timeless wool trench coat with tailored fit and premium lining."
  },
  {
    id: 5,
    name: "Canvas Sneakers",
    category: "shoes",
    price: 69.00,
    rating: 4.4,
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&q=80",
    desc: "Classic canvas sneakers with rubber sole and breathable upper."
  },
  {
    id: 6,
    name: "Stainless Steel Watch",
    category: "watches",
    price: 219.00,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1505373687837-1a1025c7c2d5?w=600&q=80",
    desc: "Polished stainless steel timepiece with water-resistant casing."
  },
  {
    id: 7,
    name: "Zip-Up Hoodie",
    category: "hoodies",
    price: 89.00,
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1578137609212-e02f17735f73?w=600&q=80",
    desc: "Lightweight zip-up hoodie with front pockets and ribbed cuffs."
  },
  {
    id: 8,
    name: "Puffer Jacket",
    category: "jackets",
    price: 179.00,
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1544996277-fd29822449ed?w=600&q=80",
    desc: "Warm puffer jacket with water-repellent shell and insulated fill."
  },
  {
    id: 9,
    name: "Leather Loafers",
    category: "shoes",
    price: 109.00,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd654d3a?w=600&q=80",
    desc: "Sophisticated leather loafers for smart-casual occasions."
  },
  {
    id: 10,
    name: "Minimal Dial Watch",
    category: "watches",
    price: 159.00,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=600&q=80",
    desc: "Ultra-minimal watch with black dial and white indices."
  },
  {
    id: 11,
    name: "Cropped Hoodie",
    category: "hoodies",
    price: 69.00,
    rating: 4.3,
    image: "https://images.unsplash.com/photo-1532383714480-e30e1456b729?w=600&q=80",
    desc: "Cropped hoodie in soft fleece for a modern, relaxed look."
  },
  {
    id: 12,
    name: "Bomber Jacket",
    category: "jackets",
    price: 159.00,
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1561758491-170144812174?w=600&q=80",
    desc: "Classic bomber jacket with ribbed collar and satin finish."
  }
];

// State loaded from LocalStorage
let cart = JSON.parse(localStorage.getItem('aurora_cart')) || [];
let wishlist = JSON.parse(localStorage.getItem('aurora_wishlist')) || [];

// Save helpers
function saveCart() {
  localStorage.setItem('aurora_cart', JSON.stringify(cart));
  updateCartBadge();
}

function saveWishlist() {
  localStorage.setItem('aurora_wishlist', JSON.stringify(wishlist));
  updateWishlistBadge();
}

// Update cart / wishlist badges in header
function updateCartBadge() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  const el = document.getElementById('cart-count');
  if (el) el.textContent = count;
  const mobile = document.getElementById('mobile-cart-count');
  if (mobile) mobile.textContent = count;
}

function updateWishlistBadge() {
  const el = document.getElementById('wishlist-count');
  if (el) el.textContent = wishlist.length;
  const mobile = document.getElementById('mobile-wishlist-count');
  if (mobile) mobile.textContent = wishlist.length;
}

// Toast notification
function showToast(msg) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// Wishlist helpers
function isInWishlist(id) {
  return wishlist.includes(id);
}

function toggleWishlist(id) {
  if (isInWishlist(id)) {
    wishlist = wishlist.filter(x => x !== id);
    showToast('Removed from wishlist');
  } else {
    wishlist.push(id);
    showToast('Added to wishlist');
  }
  saveWishlist();
  renderShopIfNeeded();
  renderWishlistPage();
  updateWishlistButtons(id);
}

// Keep the text of the wishlist buttons (quick-view window and product page) up to date
function updateWishlistButtons(id) {
  const modalBtn = document.getElementById('modal-wish-btn');
  if (modalBtn && Number(modalBtn.dataset.id) === id) {
    modalBtn.textContent = isInWishlist(id) ? 'Remove from Wishlist' : 'Add to Wishlist';
  }
  const pageBtn = document.getElementById('product-wish-btn');
  if (pageBtn && Number(pageBtn.dataset.id) === id) {
    pageBtn.textContent = isInWishlist(id) ? '❤ Remove from Wishlist' : '♡ Add to Wishlist';
  }
}

// Cart helpers
function addToCart(id, qty = 1) {
  const existing = cart.find(i => i.id === id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id, qty });
  }
  saveCart();
  showToast('Added to cart');
  renderShopIfNeeded();
}

function removeFromCart(id) {
  cart = cart.filter(i => i.id !== id);
  saveCart();
  renderCartIfNeeded();
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(id);
  } else {
    saveCart();
    renderCartIfNeeded();
  }
}

function getProduct(id) {
  return PRODUCTS.find(p => p.id === id);
}

// Build product card HTML
function productCardHTML(p) {
  const inWish = isInWishlist(p.id);
  return `
  <article class="product-card" data-id="${p.id}">
    <div class="product-img">
      <a href="product.html?id=${p.id}" class="product-link" aria-label="View details of ${p.name}"><img src="${p.image}" alt="${p.name}"></a>
      <div class="product-actions">
        <button class="quick-view" title="Quick View" onclick="openQuickView(${p.id})">QV</button>
        <button class="wishlist-btn ${inWish ? 'active' : ''}" title="Wishlist" onclick="event.stopPropagation(); toggleWishlist(${p.id})">${inWish ? '❤' : '♡'}</button>
      </div>
    </div>
    <div class="product-info">
      <div class="category">${p.category}</div>
      <h3><a href="product.html?id=${p.id}" class="product-link">${p.name}</a></h3>
      <div class="price">$${p.price.toFixed(2)}</div>
      <div class="rating">${'★'.repeat(Math.floor(p.rating))}${p.rating % 1 >= 0.5 ? '☆' : ''} (${p.rating})</div>
      <button class="add-to-cart" onclick="addToCart(${p.id})">Add to Cart</button>
    </div>
  </article>`;
}

// Render products into a container
function renderProducts(containerId, items) {
  const container = document.getElementById(containerId);
  if (!container) return;
  if (items.length === 0) {
    container.innerHTML = '<p style="text-align:center;grid-column:1/-1;color:var(--text-muted);">No products found.</p>';
    return;
  }
  container.innerHTML = items.map(p => productCardHTML(p)).join('');
}

// Re-render shop page if we are on it
function renderShopIfNeeded() {
  if (document.body.dataset.page === 'shop' && shopApply) {
    shopApply();
  }
}

// Re-render cart page if we are on it
function renderCartIfNeeded() {
  if (document.body.dataset.page !== 'cart') return;
  const container = document.getElementById('cart-items');
  const summary = document.getElementById('cart-summary');
  const empty = document.getElementById('cart-empty');
  if (!container) return;

  if (cart.length === 0) {
    if (empty) empty.style.display = 'block';
    if (container) container.style.display = 'none';
    if (summary) summary.style.display = 'none';
    return;
  }

  if (empty) empty.style.display = 'none';
  if (container) container.style.display = 'flex';
  if (summary) summary.style.display = 'block';

  let subtotal = 0;
  container.innerHTML = cart.map(item => {
    const p = getProduct(item.id);
    if (!p) return '';
    subtotal += p.price * item.qty;
    return `
    <div class="cart-item">
      <a href="product.html?id=${p.id}"><img src="${p.image}" alt="${p.name}"></a>
      <div>
        <div class="name"><a href="product.html?id=${p.id}" style="color:inherit;text-decoration:none;">${p.name}</a></div>
        <div style="color:var(--text-muted);font-size:0.9rem;">${p.category}</div>
      </div>
      <div class="price">$${p.price.toFixed(2)}</div>
      <div>
        <div class="qty-controls">
          <button onclick="changeQty(${item.id}, -1)">−</button>
          <span>${item.qty}</span>
          <button onclick="changeQty(${item.id}, 1)">+</button>
        </div>
        <div class="remove" onclick="removeFromCart(${item.id})">Remove</div>
      </div>
    </div>`;
  }).join('');

  const tax = subtotal * 0.10;
  const total = subtotal + tax;
  summary.innerHTML = `
    <div class="summary-row"><span>Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
    <div class="summary-row"><span>Tax (10%)</span><span>$${tax.toFixed(2)}</span></div>
    <div class="summary-row total"><span>Total</span><span>$${total.toFixed(2)}</span></div>
    <button class="btn" style="width:100%;margin-top:1.5rem;" onclick="proceedCheckout()">Proceed to Checkout</button>
  `;
}

// Wishlist page render
function renderWishlistPage() {
  if (document.body.dataset.page !== 'wishlist') return;
  const container = document.getElementById('wishlist-grid');
  if (!container) return;
  const items = wishlist.map(id => getProduct(id)).filter(Boolean);
  if (items.length === 0) {
    container.innerHTML = '<p style="text-align:center;grid-column:1/-1;color:var(--text-muted);">Your wishlist is empty.</p>';
    return;
  }
  container.innerHTML = items.map(p => productCardHTML(p)).join('');
}

// ========================================
// Shop Page: filters, search, sort
// ========================================
let shopApply = null;   // filled in by initShop(); re-draws the product list without resetting the filters

function initShop() {
  const grid = document.getElementById('products-grid');
  const catFilter = document.getElementById('cat-filter');
  const priceFilter = document.getElementById('price-filter');
  const sortFilter = document.getElementById('sort-filter');
  const headerSearch = document.getElementById('search-input');   // box in the header
  const shopSearch = document.getElementById('shop-search');      // box on the Shop page
  const searchInput = shopSearch || headerSearch;

  if (!grid) return;

  // Fill category dropdown
  const cats = [...new Set(PRODUCTS.map(p => p.category))];
  if (catFilter) {
    catFilter.innerHTML = '<option value="all">All Categories</option>' +
      cats.map(c => `<option value="${c}">${c.charAt(0).toUpperCase() + c.slice(1)}</option>`).join('');
  }

  // If we arrived from a category card (shop.html?cat=shoes), select that category
  const startCat = new URLSearchParams(window.location.search).get('cat');
  if (startCat && catFilter && cats.includes(startCat)) catFilter.value = startCat;

  function applyFilters() {
    let filtered = [...PRODUCTS];

    // keep the price label in sync with the slider
    const priceLabel = document.getElementById('price-val');
    if (priceLabel && priceFilter) priceLabel.textContent = '$' + priceFilter.value;

    if (catFilter && catFilter.value !== 'all') {
      filtered = filtered.filter(p => p.category === catFilter.value);
    }

    if (priceFilter) {
      const max = parseFloat(priceFilter.value);
      filtered = filtered.filter(p => p.price <= max);
    }

    if (searchInput) {
      const q = searchInput.value.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }

    if (sortFilter) {
      if (sortFilter.value === 'price-asc') filtered.sort((a, b) => a.price - b.price);
      if (sortFilter.value === 'price-desc') filtered.sort((a, b) => b.price - a.price);
    }

    renderProducts('products-grid', filtered);
  }

  shopApply = applyFilters;

  // keep the header box and the Shop-page box showing the same text
  if (headerSearch && shopSearch) {
    headerSearch.addEventListener('input', () => { shopSearch.value = headerSearch.value; });
    shopSearch.addEventListener('input', () => { headerSearch.value = shopSearch.value; });
  }
  [catFilter, priceFilter, sortFilter, headerSearch, shopSearch].forEach(el => {
    if (el) {
      const evt = el.tagName === 'INPUT' ? 'input' : 'change';
      el.addEventListener(evt, applyFilters);
    }
  });

  // If we arrived from another page's search box (shop.html?q=...), fill the boxes first
  const startQuery = new URLSearchParams(window.location.search).get('q');
  if (startQuery) {
    if (headerSearch) headerSearch.value = startQuery;
    if (shopSearch) shopSearch.value = startQuery;
  }

  applyFilters();
}

// ========================================
// Quick View Modal
// ========================================
function openQuickView(id) {
  const p = getProduct(id);
  if (!p) return;
  const modal = document.getElementById('quick-modal');
  const content = document.getElementById('quick-modal-content');
  if (!modal || !content) return;

  content.innerHTML = `
    <button class="close-modal" onclick="closeQuickView()">&times;</button>
    <div class="modal-img"><img src="${p.image}" alt="${p.name}"></div>
    <div class="modal-info">
      <div class="category">${p.category}</div>
      <h2>${p.name}</h2>
      <div class="price">$${p.price.toFixed(2)}</div>
      <div class="rating">${'★'.repeat(Math.floor(p.rating))}</div>
      <p>${p.desc}</p>
      <div class="qty-selector">
        <button onclick="changeModalQty(-1)">−</button>
        <input type="number" id="modal-qty" value="1" min="1">
        <button onclick="changeModalQty(1)">+</button>
      </div>
      <button class="btn" style="width:100%;" onclick="addToCart(${p.id}, parseInt(document.getElementById('modal-qty').value) || 1); closeQuickView();">Add to Cart</button>
      <button class="btn-outline" id="modal-wish-btn" data-id="${p.id}" style="width:100%;margin-top:0.5rem;" onclick="event.stopPropagation(); toggleWishlist(${p.id});">
        ${isInWishlist(id) ? 'Remove from Wishlist' : 'Add to Wishlist'}
      </button>
      <a href="product.html?id=${p.id}" style="display:block;text-align:center;margin-top:0.75rem;color:var(--accent);">View full details →</a>
    </div>
  `;
  modal.classList.add('open');
}

function changeModalQty(d) {
  const input = document.getElementById('modal-qty');
  if (!input) return;
  let v = parseInt(input.value) || 1;
  v = Math.max(1, v + d);
  input.value = v;
}

function closeQuickView() {
  const modal = document.getElementById('quick-modal');
  if (modal) modal.classList.remove('open');
}

// Close modal when clicking outside
document.addEventListener('click', (e) => {
  const modal = document.getElementById('quick-modal');
  if (modal && modal.classList.contains('open') && e.target === modal) {
    closeQuickView();
  }
});

// ========================================
// Checkout Page
// ========================================
// Show the order summary on the Checkout page
function renderCheckoutSummary() {
  const summary = document.getElementById('cart-summary');
  if (!summary || cart.length === 0) return;
  let subtotal = 0;
  const rows = cart.map(item => {
    const p = getProduct(item.id);
    if (!p) return '';
    subtotal += p.price * item.qty;
    return `<div class="summary-row"><span>${p.name} × ${item.qty}</span><span>$${(p.price * item.qty).toFixed(2)}</span></div>`;
  }).join('');
  const tax = subtotal * 0.10;
  summary.innerHTML = rows +
    `<div class="summary-row"><span>Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
     <div class="summary-row"><span>Tax (10%)</span><span>$${tax.toFixed(2)}</span></div>
     <div class="summary-row total"><span>Total</span><span>$${(subtotal + tax).toFixed(2)}</span></div>`;
  summary.style.display = 'block';
}

function initCheckout() {
  if (document.body.dataset.page !== 'checkout') return;
  const form = document.getElementById('checkout-form');
  const success = document.getElementById('checkout-success');
  if (!form) return;

  // Nothing to buy: show a message instead of the form
  if (cart.length === 0) {
    const grid = form.parentNode;
    const msg = document.createElement('div');
    msg.className = 'checkout-success';
    msg.innerHTML = '<h2 style="font-size:2rem;margin-bottom:1rem;">Your cart is empty</h2>' +
      '<p style="color:var(--text-muted);margin-bottom:2rem;">Add some products to your cart before checking out.</p>' +
      '<a href="shop.html" class="btn">Start Shopping</a>';
    grid.style.display = 'none';
    grid.parentNode.insertBefore(msg, grid);
    return;
  }
  renderCheckoutSummary();

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!validateCheckout()) return;
    cart = [];
    saveCart();
    const sum = document.getElementById('cart-summary');
    if (sum) sum.style.display = 'none';
    form.style.display = 'none';
    if (success) success.style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

function validateCheckout() {
  let ok = true;
  ['name', 'email', 'address', 'city', 'zip', 'card'].forEach(f => {
    const el = document.getElementById(f);
    const err = document.getElementById(f + '-error');
    if (err && !err.dataset.orig) err.dataset.orig = err.textContent;   // remember the default message
    if (!el.value.trim()) {
      el.classList.add('error');
      if (err) { err.textContent = err.dataset.orig; err.style.display = 'block'; }
      ok = false;
    } else {
      el.classList.remove('error');
      if (err) err.style.display = 'none';
    }
  });
  // card number: 13 to 19 digits (spaces or dashes allowed)
  const card = document.getElementById('card');
  const cardErr = document.getElementById('card-error');
  if (card && card.value.trim() && !/^\d{13,19}$/.test(card.value.replace(/[\s-]/g, ''))) {
    card.classList.add('error');
    if (cardErr) { cardErr.textContent = 'Enter a valid card number (13 to 19 digits)'; cardErr.style.display = 'block'; }
    ok = false;
  }
  const email = document.getElementById('email');
  const emailErr = document.getElementById('email-error');
  if (email && email.value.trim() && !/^\S+@\S+\.\S+$/.test(email.value)) {
    email.classList.add('error');
    if (emailErr) {
      emailErr.textContent = 'Enter a valid email';
      emailErr.style.display = 'block';
    }
    ok = false;
  }
  return ok;
}

function proceedCheckout() {
  window.location.href = 'checkout.html';
}

// ========================================
// Contact Page
// ========================================
function initContact() {
  if (document.body.dataset.page !== 'contact') return;
  const form = document.getElementById('contact-form');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let ok = true;
    ['name', 'email', 'message'].forEach(f => {
      const el = document.getElementById(f);
      const err = document.getElementById(f + '-error');
      const value = el.value.trim();
      const badEmail = f === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      if (!value || badEmail) {
        el.classList.add('error');
        if (err) err.style.display = 'block';
        ok = false;
      } else {
        el.classList.remove('error');
        if (err) err.style.display = 'none';
      }
    });
    if (ok) {
      alert('Thank you! Your message has been sent.');
      form.reset();
    }
  });
}


// ========================================
// Product Detail Page (product.html?id=...)
// ========================================
const PRODUCT_HIGHLIGHTS = {
  1: ['Handcrafted leather', 'Sleek Chelsea boot silhouette', 'Cushioned insole'],
  2: ['Elegant analog watch', 'Clean, minimal dial', 'Genuine leather strap'],
  3: ['Oversized fit', 'Premium cotton blend', 'Soft everyday comfort'],
  4: ['Timeless wool trench coat', 'Tailored fit', 'Premium lining'],
  5: ['Classic canvas upper', 'Rubber sole', 'Breathable design'],
  6: ['Polished stainless steel', 'Water-resistant casing', 'Timeless timepiece'],
  7: ['Lightweight zip-up design', 'Front pockets', 'Ribbed cuffs'],
  8: ['Water-repellent shell', 'Insulated fill for warmth', 'Puffer jacket style'],
  9: ['Leather loafers', 'Sophisticated look', 'Suited to smart-casual occasions'],
  10: ['Ultra-minimal design', 'Black dial', 'White indices'],
  11: ['Cropped cut', 'Soft fleece', 'Modern, relaxed look'],
  12: ['Classic bomber style', 'Ribbed collar', 'Satin finish']
};

function changeDetailQty(d) {
  const input = document.getElementById('detail-qty');
  if (!input) return;
  input.value = Math.max(1, (parseInt(input.value) || 1) + d);
}

function detailQty() {
  const input = document.getElementById('detail-qty');
  return Math.max(1, parseInt(input && input.value) || 1);
}

function buyNow(id) {
  addToCart(id, detailQty());
  window.location.href = 'checkout.html';
}

function initProduct() {
  if (document.body.dataset.page !== 'product') return;
  const box = document.getElementById('product-detail');
  if (!box) return;
  const id = parseInt(new URLSearchParams(window.location.search).get('id'));
  const p = getProduct(id);

  if (!p) {
    box.innerHTML = `<div class="checkout-success">
      <h2 style="font-size:2rem;margin-bottom:1rem;">Product not found</h2>
      <p style="color:var(--text-muted);margin-bottom:2rem;">Sorry, we could not find that product.</p>
      <a href="shop.html" class="btn">Back to Shop</a></div>`;
    return;
  }

  const catName = p.category.charAt(0).toUpperCase() + p.category.slice(1);
  const stars = '★'.repeat(Math.floor(p.rating)) + (p.rating % 1 >= 0.5 ? '☆' : '');
  const highlights = (PRODUCT_HIGHLIGHTS[p.id] || []).map(h => `<li>${h}</li>`).join('');
  document.title = p.name + ' | Aurora';

  box.innerHTML = `
    <nav class="breadcrumb">
      <a href="index.html">Home</a> / <a href="shop.html">Shop</a> /
      <a href="shop.html?cat=${p.category}">${catName}</a> / <span>${p.name}</span>
    </nav>
    <div class="detail-grid">
      <div class="detail-img"><img src="${p.image}" alt="${p.name}"></div>
      <div class="detail-info">
        <div class="category">${catName}</div>
        <h1>${p.name}</h1>
        <div class="rating">${stars} (${p.rating} / 5)</div>
        <div class="price">$${p.price.toFixed(2)}</div>
        <h3 class="detail-heading">Description</h3>
        <p class="detail-desc">${p.desc}</p>
        <h3 class="detail-heading">Highlights</h3>
        <ul class="detail-list">${highlights}</ul>
        <div class="qty-selector" style="margin-bottom:1rem;">
          <button onclick="changeDetailQty(-1)">−</button>
          <input type="number" id="detail-qty" value="1" min="1">
          <button onclick="changeDetailQty(1)">+</button>
        </div>
        <div class="detail-buttons">
          <button class="btn" id="detail-add" onclick="addToCart(${p.id}, detailQty())">Add to Cart</button>
          <button class="btn" id="detail-buy" onclick="buyNow(${p.id})">Buy Now</button>
          <button class="btn-outline" id="product-wish-btn" data-id="${p.id}" onclick="toggleWishlist(${p.id})">${isInWishlist(p.id) ? '❤ Remove from Wishlist' : '♡ Add to Wishlist'}</button>
        </div>
        <a href="shop.html" class="back-link">← Back to Shop</a>
      </div>
    </div>`;

  // Related products (same category)
  const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id);
  const section = document.getElementById('related-section');
  if (section && related.length) {
    section.style.display = 'block';
    renderProducts('related-grid', related);
  }
}

// ========================================
// Header / Mobile Menu
// ========================================
function initHeader() {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => mobileMenu.classList.toggle('active'));
  }
  updateCartBadge();
  updateWishlistBadge();

  // Newsletter box in the footer (present on every page)
  document.querySelectorAll('.newsletter').forEach(box => {
    const input = box.querySelector('input');
    const button = box.querySelector('button');
    if (!input || !button) return;
    button.addEventListener('click', () => {
      const email = input.value.trim();
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showToast('Thanks for subscribing!');
        input.value = '';
      } else {
        showToast('Please enter a valid email address');
      }
    });
  });

  // On pages other than Shop, pressing Enter in the header search opens the Shop page with the results
  const headerSearchBox = document.getElementById('search-input');
  if (headerSearchBox && document.body.dataset.page !== 'shop') {
    headerSearchBox.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const q = headerSearchBox.value.trim();
      if (q) window.location.href = 'shop.html?q=' + encodeURIComponent(q);
    });
  }
}

// ========================================
// Global Init
// ========================================
document.addEventListener('DOMContentLoaded', () => {
  initHeader();

  const page = document.body.dataset.page || '';

  if (page === 'shop') initShop();
  if (page === 'checkout') initCheckout();
  if (page === 'contact') initContact();
  if (page === 'product') initProduct();
  if (page === 'home') {
    const featured = document.getElementById('featured-grid');
    if (featured) renderProducts('featured-grid', PRODUCTS.slice(0, 4));
  }

  renderCartIfNeeded();
  renderWishlistPage();
});

// Expose functions to inline HTML onclick handlers
window.addToCart = addToCart;
window.toggleWishlist = toggleWishlist;
window.changeQty = changeQty;
window.removeFromCart = removeFromCart;
window.openQuickView = openQuickView;
window.closeQuickView = closeQuickView;
window.changeModalQty = changeModalQty;
window.proceedCheckout = proceedCheckout;
// ========================================
// Image fallback: if a picture cannot be loaded (broken link, no internet),
// show a clean placeholder with the picture's name instead of a broken icon.
// ========================================
function imagePlaceholder(label) {
  const text = (label || 'Image').replace(/[<>&"]/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
    <rect width="600" height="600" fill="#efece8"/>
    <rect x="30" y="30" width="540" height="540" fill="none" stroke="#b9975b" stroke-width="2" stroke-dasharray="10 8"/>
    <text x="300" y="290" font-family="Georgia, serif" font-size="34" text-anchor="middle" fill="#8c7a6b">AURORA</text>
    <text x="300" y="340" font-family="Arial, sans-serif" font-size="24" text-anchor="middle" fill="#6b6b6b">${text}</text>
  </svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}
function useFallback(img) {
  if (!img || img.tagName !== 'IMG' || img.dataset.fallback) return;
  img.dataset.fallback = '1';
  img.src = imagePlaceholder(img.alt);
}
// Catches images that fail while the page is running (including ones added by JavaScript)
document.addEventListener('error', (e) => useFallback(e.target), true);
// Catches images that had already failed before the line above was running
window.addEventListener('load', () => {
  document.querySelectorAll('img').forEach(img => {
    if (img.complete && img.naturalWidth === 0) useFallback(img);
  });
});
